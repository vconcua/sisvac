-- ============================================================
-- Migración 004: catálogo oficial de departamentos y municipios
-- de Guatemala (22 departamentos, 340 municipios).
-- Fuente verificada: Anexo:Municipios de Guatemala (Wikipedia,
-- consultado agosto 2026), contrastado contra división territorial
-- vigente (INE / SEGEPLAN). Se recomienda validar contra el
-- codificador oficial del INE si se requiere para reportes
-- estadísticos formales: https://www.ine.gob.gt
-- ============================================================

CREATE TABLE IF NOT EXISTS departamentos (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS municipios (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    departamento_id INTEGER NOT NULL REFERENCES departamentos(id) ON DELETE CASCADE,
    UNIQUE (nombre, departamento_id)
);
CREATE INDEX IF NOT EXISTS idx_municipios_departamento ON municipios(departamento_id);

-- Relacionar comunidades con el catálogo normalizado, manteniendo
-- las columnas de texto existentes (departamento, municipio) por
-- compatibilidad con datos ya cargados.
ALTER TABLE comunidades ADD COLUMN IF NOT EXISTS departamento_id INTEGER REFERENCES departamentos(id);
ALTER TABLE comunidades ADD COLUMN IF NOT EXISTS municipio_id INTEGER REFERENCES municipios(id);

-- ============================================================
-- Datos: 22 departamentos
-- ============================================================
INSERT INTO departamentos (nombre) VALUES
    ('Alta Verapaz'),
    ('Baja Verapaz'),
    ('Chimaltenango'),
    ('Chiquimula'),
    ('El Progreso'),
    ('Escuintla'),
    ('Guatemala'),
    ('Huehuetenango'),
    ('Izabal'),
    ('Jalapa'),
    ('Jutiapa'),
    ('Petén'),
    ('Quetzaltenango'),
    ('Quiché'),
    ('Retalhuleu'),
    ('Sacatepéquez'),
    ('San Marcos'),
    ('Santa Rosa'),
    ('Sololá'),
    ('Suchitepéquez'),
    ('Totonicapán'),
    ('Zacapa')
ON CONFLICT (nombre) DO NOTHING;

-- ============================================================
-- Datos: 340 municipios (agrupados por departamento)
-- ============================================================
-- Alta Verapaz (17 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Chahal', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Chisec', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Cobán', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Fray Bartolomé de las Casas', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Santa Catalina La Tinta', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Lanquín', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Panzós', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Raxruhá', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('San Cristóbal Verapaz', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('San Juan Chamelco', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('San Pedro Carchá', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Santa Cruz Verapaz', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Santa María Cahabón', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Senahú', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Tamahú', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Tactic', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz')),
    ('Tucurú', (SELECT id FROM departamentos WHERE nombre = 'Alta Verapaz'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Baja Verapaz (8 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Cubulco', (SELECT id FROM departamentos WHERE nombre = 'Baja Verapaz')),
    ('Granados', (SELECT id FROM departamentos WHERE nombre = 'Baja Verapaz')),
    ('Purulhá', (SELECT id FROM departamentos WHERE nombre = 'Baja Verapaz')),
    ('Rabinal', (SELECT id FROM departamentos WHERE nombre = 'Baja Verapaz')),
    ('Salamá', (SELECT id FROM departamentos WHERE nombre = 'Baja Verapaz')),
    ('San Jerónimo', (SELECT id FROM departamentos WHERE nombre = 'Baja Verapaz')),
    ('San Miguel Chicaj', (SELECT id FROM departamentos WHERE nombre = 'Baja Verapaz')),
    ('Santa Cruz el Chol', (SELECT id FROM departamentos WHERE nombre = 'Baja Verapaz'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Chimaltenango (16 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Acatenango', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Chimaltenango', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('El Tejar', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Parramos', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Patzicía', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Patzún', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Pochuta', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('San Andrés Itzapa', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('San José Poaquíl', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('San Juan Comalapa', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('San Martín Jilotepeque', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Santa Apolonia', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Santa Cruz Balanyá', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Tecpán', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Yepocapa', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango')),
    ('Zaragoza', (SELECT id FROM departamentos WHERE nombre = 'Chimaltenango'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Chiquimula (11 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Camotán', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('Chiquimula', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('Concepción Las Minas', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('Esquipulas', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('Ipala', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('Jocotán', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('Olopa', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('Quetzaltepeque', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('San Jacinto', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('San José la Arada', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula')),
    ('San Juan Ermita', (SELECT id FROM departamentos WHERE nombre = 'Chiquimula'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- El Progreso (8 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('El Jícaro', (SELECT id FROM departamentos WHERE nombre = 'El Progreso')),
    ('Guastatoya', (SELECT id FROM departamentos WHERE nombre = 'El Progreso')),
    ('Morazán', (SELECT id FROM departamentos WHERE nombre = 'El Progreso')),
    ('San Agustín Acasaguastlán', (SELECT id FROM departamentos WHERE nombre = 'El Progreso')),
    ('San Antonio La Paz', (SELECT id FROM departamentos WHERE nombre = 'El Progreso')),
    ('San Cristóbal Acasaguastlán', (SELECT id FROM departamentos WHERE nombre = 'El Progreso')),
    ('Sanarate', (SELECT id FROM departamentos WHERE nombre = 'El Progreso')),
    ('Sansare', (SELECT id FROM departamentos WHERE nombre = 'El Progreso'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Escuintla (14 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Escuintla', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('Guanagazapa', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('Iztapa', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('La Democracia', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('La Gomera', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('Masagua', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('Nueva Concepción', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('Palín', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('San José', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('San Vicente Pacaya', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('Santa Lucía Cotzumalguapa', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('Sipacate', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('Siquinalá', (SELECT id FROM departamentos WHERE nombre = 'Escuintla')),
    ('Tiquisate', (SELECT id FROM departamentos WHERE nombre = 'Escuintla'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Guatemala (17 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Amatitlán', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('Chinautla', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('Chuarrancho', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('Ciudad de Guatemala', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('Fraijanes', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('Mixco', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('Palencia', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('San José del Golfo', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('San José Pinula', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('San Juan Sacatepéquez', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('San Miguel Petapa', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('San Pedro Ayampuc', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('San Pedro Sacatepéquez', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('San Raymundo', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('Santa Catarina Pinula', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('Villa Canales', (SELECT id FROM departamentos WHERE nombre = 'Guatemala')),
    ('Villa Nueva', (SELECT id FROM departamentos WHERE nombre = 'Guatemala'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Huehuetenango (33 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Aguacatán', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Chiantla', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Colotenango', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Concepción Huista', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Cuilco', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Huehuetenango', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Jacaltenango', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('La Democracia', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('La Libertad', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Malacatancito', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Nentón', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Petatán', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Antonio Huista', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Gaspar Ixchil', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Ildefonso Ixtahuacán', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Juan Atitán', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Juan Ixcoy', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Mateo Ixtatán', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Miguel Acatán', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Pedro Nécta', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Pedro Soloma', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Rafael La Independencia', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Rafael Pétzal', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Sebastián Coatán', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('San Sebastián Huehuetenango', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Santa Ana Huista', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Santa Bárbara', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Santa Cruz Barillas', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Santa Eulalia', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Santiago Chimaltenango', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Tectitán', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Todos Santos Cuchumatán', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango')),
    ('Unión Cantinil', (SELECT id FROM departamentos WHERE nombre = 'Huehuetenango'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Izabal (5 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('El Estor', (SELECT id FROM departamentos WHERE nombre = 'Izabal')),
    ('Livingston', (SELECT id FROM departamentos WHERE nombre = 'Izabal')),
    ('Los Amates', (SELECT id FROM departamentos WHERE nombre = 'Izabal')),
    ('Morales', (SELECT id FROM departamentos WHERE nombre = 'Izabal')),
    ('Puerto Barrios', (SELECT id FROM departamentos WHERE nombre = 'Izabal'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Jalapa (7 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Jalapa', (SELECT id FROM departamentos WHERE nombre = 'Jalapa')),
    ('Mataquescuintla', (SELECT id FROM departamentos WHERE nombre = 'Jalapa')),
    ('Monjas', (SELECT id FROM departamentos WHERE nombre = 'Jalapa')),
    ('San Carlos Alzatate', (SELECT id FROM departamentos WHERE nombre = 'Jalapa')),
    ('San Luis Jilotepeque', (SELECT id FROM departamentos WHERE nombre = 'Jalapa')),
    ('San Manuel Chaparrón', (SELECT id FROM departamentos WHERE nombre = 'Jalapa')),
    ('San Pedro Pinula', (SELECT id FROM departamentos WHERE nombre = 'Jalapa'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Jutiapa (17 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Agua Blanca', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Asunción Mita', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Atescatempa', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Comapa', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Conguaco', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('El Adelanto', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('El Progreso', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Jalpatagua', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Jerez', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Jutiapa', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Moyuta', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Pasaco', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Quesada', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('San José Acatempa', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Santa Catarina Mita', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Yupiltepeque', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa')),
    ('Zapotitlán', (SELECT id FROM departamentos WHERE nombre = 'Jutiapa'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Petén (14 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Dolores', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('El Chal', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('Flores', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('La Libertad', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('Las Cruces', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('Melchor de Mencos', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('Poptún', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('San Andrés', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('San Benito', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('San Francisco', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('San José', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('San Luis', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('Santa Ana', (SELECT id FROM departamentos WHERE nombre = 'Petén')),
    ('Sayaxché', (SELECT id FROM departamentos WHERE nombre = 'Petén'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Quetzaltenango (24 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Almolonga', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Cabricán', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Cajolá', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Cantel', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Coatepeque', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Colomba', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Concepción Chiquirichapa', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('El Palmar', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Flores Costa Cuca', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Génova', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Huitán', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('La Esperanza', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Olintepeque', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Palestina de Los Altos', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Quetzaltenango', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Salcajá', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('San Carlos Sija', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('San Francisco La Unión', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('San Juan Ostuncalco', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('San Martín Sacatepéquez', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('San Mateo', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('San Miguel Sigüilá', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Sibilia', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango')),
    ('Zunil', (SELECT id FROM departamentos WHERE nombre = 'Quetzaltenango'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Quiché (21 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Canillá', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Chajul', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Chicamán', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Chiché', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Santo Tomás Chichicastenango', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Chinique', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Cunén', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Ixcán', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Joyabaj', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Nebaj', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Pachalum', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Patzité', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Sacapulas', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('San Andrés Sajcabajá', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('San Antonio Ilotenango', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('San Bartolomé Jocotenango', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('San Juan Cotzal', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('San Pedro Jocopilas', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Santa Cruz del Quiché', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Uspantán', (SELECT id FROM departamentos WHERE nombre = 'Quiché')),
    ('Zacualpa', (SELECT id FROM departamentos WHERE nombre = 'Quiché'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Retalhuleu (9 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Champerico', (SELECT id FROM departamentos WHERE nombre = 'Retalhuleu')),
    ('El Asintal', (SELECT id FROM departamentos WHERE nombre = 'Retalhuleu')),
    ('Nuevo San Carlos', (SELECT id FROM departamentos WHERE nombre = 'Retalhuleu')),
    ('Retalhuleu', (SELECT id FROM departamentos WHERE nombre = 'Retalhuleu')),
    ('San Andrés Villa Seca', (SELECT id FROM departamentos WHERE nombre = 'Retalhuleu')),
    ('San Felipe', (SELECT id FROM departamentos WHERE nombre = 'Retalhuleu')),
    ('San Martín Zapotitlán', (SELECT id FROM departamentos WHERE nombre = 'Retalhuleu')),
    ('San Sebastián', (SELECT id FROM departamentos WHERE nombre = 'Retalhuleu')),
    ('Santa Cruz Muluá', (SELECT id FROM departamentos WHERE nombre = 'Retalhuleu'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Sacatepéquez (16 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Alotenango', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Ciudad Vieja', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Jocotenango', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('La Antigua Guatemala', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Magdalena Milpas Altas', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Pastores', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('San Antonio Aguas Calientes', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('San Bartolomé Milpas Altas', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('San Lucas Sacatepéquez', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('San Miguel Dueñas', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Santa Catarina Barahona', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Santa Lucía Milpas Altas', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Santa María de Jesús', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Santiago Sacatepéquez', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Santo Domingo Xenacoj', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez')),
    ('Sumpango', (SELECT id FROM departamentos WHERE nombre = 'Sacatepéquez'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- San Marcos (30 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Ayutla', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Catarina', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Comitancillo', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Concepción Tutuapa', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('El Quetzal', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('El Tumbador', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Esquipulas Palo Gordo', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Ixchiguán', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('La Blanca', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('La Reforma', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Malacatán', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Nuevo Progreso', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Ocós', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Pajapita', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Río Blanco', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San Antonio Sacatepéquez', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San Cristóbal Cucho', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San José El Rodeo', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San José Ojetenam', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San Lorenzo', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San Marcos', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San Miguel Ixtahuacán', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San Pablo', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San Pedro Sacatepéquez', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('San Rafael Pie de la Cuesta', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Sibinal', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Sipacapa', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Tacaná', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Tajumulco', (SELECT id FROM departamentos WHERE nombre = 'San Marcos')),
    ('Tejutla', (SELECT id FROM departamentos WHERE nombre = 'San Marcos'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Santa Rosa (14 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Barberena', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Casillas', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Chiquimulilla', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Cuilapa', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Guazacapán', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Nueva Santa Rosa', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Oratorio', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Pueblo Nuevo Viñas', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('San Juan Tecuaco', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('San Rafael las Flores', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Santa Cruz Naranjo', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Santa María Ixhuatán', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Santa Rosa de Lima', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa')),
    ('Taxisco', (SELECT id FROM departamentos WHERE nombre = 'Santa Rosa'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Sololá (19 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Concepción', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Nahualá', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Panajachel', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('San Andrés Semetabaj', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('San Antonio Palopó', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('San José Chacayá', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('San Juan La Laguna', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('San Lucas Tolimán', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('San Marcos La Laguna', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('San Pablo La Laguna', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('San Pedro La Laguna', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Santa Catarina Ixtahuacán', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Santa Catarina Palopó', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Santa Clara La Laguna', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Santa Cruz La Laguna', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Santa Lucía Utatlán', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Santa María Visitación', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Santiago Atitlán', (SELECT id FROM departamentos WHERE nombre = 'Sololá')),
    ('Sololá', (SELECT id FROM departamentos WHERE nombre = 'Sololá'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Suchitepéquez (21 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Chicacao', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Cuyotenango', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Mazatenango', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Patulul', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Pueblo Nuevo', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Río Bravo', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Samayac', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San Antonio Suchitepéquez', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San Bernardino', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San Francisco Zapotitlán', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San Gabriel', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San José El Idolo', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San José La Maquina', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San Juan Bautista', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San Lorenzo', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San Miguel Panán', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('San Pablo Jocopilas', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Santa Bárbara', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Santo Domingo Suchitepéquez', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Santo Tomás La Unión', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez')),
    ('Zunilito', (SELECT id FROM departamentos WHERE nombre = 'Suchitepéquez'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Totonicapán (8 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Momostenango', (SELECT id FROM departamentos WHERE nombre = 'Totonicapán')),
    ('San Andrés Xecul', (SELECT id FROM departamentos WHERE nombre = 'Totonicapán')),
    ('San Bartolo', (SELECT id FROM departamentos WHERE nombre = 'Totonicapán')),
    ('San Cristóbal Totonicapán', (SELECT id FROM departamentos WHERE nombre = 'Totonicapán')),
    ('San Francisco El Alto', (SELECT id FROM departamentos WHERE nombre = 'Totonicapán')),
    ('Santa Lucía La Reforma', (SELECT id FROM departamentos WHERE nombre = 'Totonicapán')),
    ('Santa María Chiquimula', (SELECT id FROM departamentos WHERE nombre = 'Totonicapán')),
    ('Totonicapán', (SELECT id FROM departamentos WHERE nombre = 'Totonicapán'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;

-- Zacapa (11 municipios)
INSERT INTO municipios (nombre, departamento_id) VALUES
    ('Cabañas', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('Estanzuela', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('Gualán', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('Huité', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('La Unión', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('Río Hondo', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('San Diego', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('San Jorge', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('Teculután', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('Usumatlán', (SELECT id FROM departamentos WHERE nombre = 'Zacapa')),
    ('Zacapa', (SELECT id FROM departamentos WHERE nombre = 'Zacapa'))
ON CONFLICT (nombre, departamento_id) DO NOTHING;
